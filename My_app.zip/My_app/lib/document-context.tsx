import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Document, DocumentType, DocumentStats } from '@/types/document';

interface DocumentContextType {
  documents: Document[];
  loading: boolean;
  error: string | null;
  addDocument: (document: Omit<Document, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  deleteDocument: (id: string) => Promise<void>;
  getDocumentById: (id: string) => Document | undefined;
  getDocumentsByType: (type: DocumentType) => Document[];
  getStats: () => DocumentStats;
  searchDocuments: (query: string) => Document[];
}

const DocumentContext = createContext<DocumentContextType | undefined>(undefined);

const STORAGE_KEY = '@doc_archive_documents';

export function DocumentProvider({ children }: { children: React.ReactNode }) {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load documents from storage on mount
  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await AsyncStorage.getItem(STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data) as Document[];
        setDocuments(parsed);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load documents');
      console.error('Error loading documents:', err);
    } finally {
      setLoading(false);
    }
  };

  const saveDocuments = async (docs: Document[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(docs));
      setDocuments(docs);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save documents');
      console.error('Error saving documents:', err);
      throw err;
    }
  };

  const addDocument = async (document: Omit<Document, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      setError(null);
      const now = new Date().toISOString();
      const newDocument: Document = {
        ...document,
        id: `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        createdAt: now,
        updatedAt: now,
      };
      await saveDocuments([...documents, newDocument]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add document');
      throw err;
    }
  };

  const deleteDocument = async (id: string) => {
    try {
      setError(null);
      const updated = documents.filter(doc => doc.id !== id);
      await saveDocuments(updated);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete document');
      throw err;
    }
  };

  const getDocumentById = (id: string) => {
    return documents.find(doc => doc.id === id);
  };

  const getDocumentsByType = (type: DocumentType) => {
    return documents.filter(doc => doc.type === type);
  };

  const getStats = (): DocumentStats => {
    return {
      totalDocuments: documents.length,
      outgoingCount: documents.filter(d => d.type === 'outgoing').length,
      incomingCount: documents.filter(d => d.type === 'incoming').length,
      recentDocuments: documents.slice(-5).reverse(),
    };
  };

  const searchDocuments = (query: string): Document[] => {
    if (!query.trim()) return [];
    
    const lowerQuery = query.toLowerCase();
    return documents.filter(doc => {
      // Search in reference number
      if (doc.referenceNumber.toLowerCase().includes(lowerQuery)) return true;
      // Search in subject
      if (doc.subject.toLowerCase().includes(lowerQuery)) return true;
      // Search in date
      if (doc.date.includes(query)) return true;
      return false;
    });
  };

  return (
    <DocumentContext.Provider
      value={{
        documents,
        loading,
        error,
        addDocument,
        deleteDocument,
        getDocumentById,
        getDocumentsByType,
        getStats,
        searchDocuments,
      }}
    >
      {children}
    </DocumentContext.Provider>
  );
}

export function useDocuments() {
  const context = useContext(DocumentContext);
  if (context === undefined) {
    throw new Error('useDocuments must be used within a DocumentProvider');
  }
  return context;
}
