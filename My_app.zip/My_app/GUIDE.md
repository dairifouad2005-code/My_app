# دليل تطوير تطبيق أرشفة الوثائق

## 📁 هيكل المشروع

```
doc-archive-app/
├── app/                          # جميع شاشات التطبيق
│   ├── (tabs)/                   # الشاشات الرئيسية (التنقل السفلي)
│   │   ├── index.tsx             # الشاشة الرئيسية (Home)
│   │   ├── outgoing.tsx          # شاشة الوثائق الصادرة
│   │   ├── incoming.tsx          # شاشة الوثائق الواردة
│   │   ├── search.tsx            # شاشة البحث
│   │   ├── document-detail.tsx   # تفاصيل الوثيقة (عرض، تحميل، حذف)
│   │   └── _layout.tsx           # إعدادات التنقل السفلي
│   ├── add-document.tsx          # شاشة إضافة وثيقة جديدة
│   ├── _layout.tsx               # الملف الرئيسي للتطبيق
│   └── oauth/callback.tsx        # معالجة المصادقة
├── components/                   # المكونات القابلة لإعادة الاستخدام
│   ├── screen-container.tsx      # غلاف الشاشة (SafeArea)
│   ├── themed-view.tsx           # عرض مع دعم المواضيع
│   └── ui/
│       └── icon-symbol.tsx       # مكون الأيقونات
├── lib/                          # مكتبات وأدوات
│   ├── document-context.tsx      # إدارة حالة الوثائق (Context API)
│   ├── theme-provider.tsx        # إدارة المواضيع (Light/Dark)
│   ├── utils.ts                  # دوال مساعدة (cn, etc)
│   └── trpc.ts                   # إعدادات API
├── hooks/                        # React Hooks مخصصة
│   ├── use-colors.ts             # الألوان الحالية
│   ├── use-color-scheme.ts       # الوضع الفاتح/الداكن
│   └── use-auth.ts               # المصادقة
├── types/                        # أنواع TypeScript
│   └── document.ts               # أنواع الوثائق
├── constants/                    # الثوابت
│   └── theme.ts                  # ألوان المواضيع
├── assets/                       # الصور والملفات الثابتة
│   └── images/
│       ├── icon.png              # أيقونة التطبيق
│       ├── splash-icon.png       # أيقونة شاشة البداية
│       └── favicon.png           # أيقونة المتصفح
├── app.config.ts                 # إعدادات Expo الرئيسية
├── tailwind.config.js            # إعدادات Tailwind CSS
├── theme.config.js               # إعدادات الألوان
├── package.json                  # المكتبات والتبعيات
└── todo.md                       # قائمة المهام

```

---

## 🎯 الملفات المهمة وشرح وظائفها

### 1️⃣ `lib/document-context.tsx` - إدارة الوثائق
هذا الملف يدير جميع بيانات الوثائق (الحفظ، الحذف، البحث)

```typescript
// الدوال المتاحة:
- addDocument()      // إضافة وثيقة جديدة
- deleteDocument()   // حذف وثيقة
- getDocumentById()  // الحصول على وثيقة بـ ID
- searchDocuments()  // البحث عن وثائق
- getOutgoing()      // الحصول على الوثائق الصادرة
- getIncoming()      // الحصول على الوثائق الواردة
```

### 2️⃣ `types/document.ts` - أنواع البيانات
يحتوي على تعريف بنية الوثيقة

```typescript
interface Document {
  id: string;              // معرف فريد
  type: 'outgoing' | 'incoming';  // نوع الوثيقة
  referenceNumber: string; // الرقم الإشاري
  subject: string;         // الموضوع
  date: string;            // تاريخ الوثيقة
  pdfUri: string;          // رابط ملف PDF
  createdAt: string;       // تاريخ الإنشاء
}
```

### 3️⃣ `app/(tabs)/index.tsx` - الشاشة الرئيسية
تعرض الإحصائيات والوثائق الأخيرة

### 4️⃣ `app/(tabs)/search.tsx` - شاشة البحث
تطبق نظام البحث الذكي بالرقم والتاريخ والموضوع

### 5️⃣ `app/(tabs)/document-detail.tsx` - تفاصيل الوثيقة
تحتوي على أزرار العرض والتحميل والحذف

---

## 🛠️ كيفية التعديل على الأكواد

### الطريقة الأولى: استخدام VS Code (الأفضل والأسهل)

#### الخطوة 1: تحميل المشروع
```bash
# انسخ مسار المشروع:
/home/ubuntu/doc-archive-app

# افتح VS Code وقم بـ:
1. File → Open Folder
2. اختر المجلد /home/ubuntu/doc-archive-app
```

#### الخطوة 2: تثبيت الإضافات المفيدة
في VS Code، اذهب إلى Extensions (Ctrl+Shift+X) وثبت:
- **ES7+ React/Redux/React-Native snippets** - لتسريع الكتابة
- **Tailwind CSS IntelliSense** - للألوان والـ Classes
- **TypeScript Vue Plugin** - لدعم TypeScript

#### الخطوة 3: فهم الملفات
- **الملفات بصيغة `.tsx`**: تحتوي على React Components (الواجهات)
- **الملفات بصيغة `.ts`**: تحتوي على Logic و Utilities (المنطق)
- **الملفات بصيغة `.js`**: ملفات إعدادات

#### الخطوة 4: التعديل على الأكواد
مثال: تغيير نص الزر في الشاشة الرئيسية

```typescript
// في ملف app/(tabs)/index.tsx
// ابحث عن هذا السطر:
<Text className="text-2xl font-bold text-foreground">أضف وثيقة جديدة</Text>

// غيره إلى:
<Text className="text-2xl font-bold text-foreground">إضافة وثيقة</Text>
```

---

## 🎨 تخصيص الألوان والتصميم

### تغيير الألوان الأساسية
في ملف `theme.config.js`:

```javascript
const themeColors = {
  primary: { light: '#0a7ea4', dark: '#0a7ea4' },      // اللون الأساسي
  background: { light: '#ffffff', dark: '#151718' },   // لون الخلفية
  foreground: { light: '#11181C', dark: '#ECEDEE' },   // لون النص
  // ... ألوان أخرى
};
```

### استخدام الألوان في الأكواد
```typescript
// استخدم className مع Tailwind:
<View className="bg-primary">           {/* خلفية زرقاء */}
<Text className="text-foreground">      {/* نص أسود/أبيض */}
<View className="border border-border">  {/* حد رمادي */}
```

---

## 📱 إضافة ميزات جديدة

### مثال: إضافة زر جديد في الشاشة الرئيسية

#### الخطوة 1: افتح `app/(tabs)/index.tsx`

#### الخطوة 2: أضف الزر الجديد
```typescript
<TouchableOpacity
  onPress={() => {
    // الإجراء عند الضغط على الزر
    console.log('تم الضغط على الزر');
  }}
  className="bg-primary rounded-xl p-4 active:opacity-80"
>
  <Text className="text-white font-bold text-center">
    اسم الزر الجديد
  </Text>
</TouchableOpacity>
```

#### الخطوة 3: احفظ الملف (Ctrl+S)
التطبيق سيحدّث نفسه تلقائياً!

---

## 🔍 البحث والاستبدال السريع

في VS Code:
- **Ctrl+F**: البحث عن نص
- **Ctrl+H**: البحث والاستبدال
- **Ctrl+Shift+F**: البحث في جميع الملفات

مثال: تغيير جميع كلمات "وثيقة" إلى "ملف":
1. اضغط Ctrl+H
2. اكتب "وثيقة" في حقل البحث
3. اكتب "ملف" في حقل الاستبدال
4. اضغط "Replace All"

---

## 🚀 تشغيل التطبيق محلياً

### على الويب (الأسهل):
```bash
cd /home/ubuntu/doc-archive-app
pnpm dev
```
ثم افتح: https://8081-i3a9lixdpz7vwdpuzjtss-f988e398.us2.manus.computer

### على الهاتف (iOS/Android):
```bash
# للـ iOS
pnpm ios

# للـ Android
pnpm android
```

---

## 📝 أمثلة عملية للتعديل

### مثال 1: تغيير رسالة الترحيب
**الملف**: `app/(tabs)/index.tsx`
```typescript
// البحث عن:
<Text className="text-4xl font-bold text-foreground">نظام الأرشفة</Text>

// غيره إلى:
<Text className="text-4xl font-bold text-foreground">إدارة الوثائق الذكية</Text>
```

### مثال 2: إضافة حقل جديد للوثيقة
**الملف 1**: `types/document.ts`
```typescript
interface Document {
  // ... الحقول الموجودة
  notes?: string;  // أضف هذا الحقل
}
```

**الملف 2**: `app/add-document.tsx`
```typescript
// أضف state جديد:
const [notes, setNotes] = useState('');

// أضف input جديد:
<TextInput
  placeholder="ملاحظات (اختياري)"
  value={notes}
  onChangeText={setNotes}
  className="border border-border rounded-lg p-3"
/>
```

### مثال 3: تغيير عدد الأيقونات في شريط التنقل
**الملف**: `app/(tabs)/_layout.tsx`
```typescript
// أضف Tab جديد:
<Tabs.Screen
  name="settings"
  options={{
    title: "الإعدادات",
    tabBarIcon: ({ color }) => <IconSymbol size={28} name="gear" color={color} />,
  }}
/>
```

---

## 🐛 حل المشاكل الشائعة

### المشكلة: الأكواد لا تتحدث تلقائياً
**الحل**: احفظ الملف يدوياً (Ctrl+S)

### المشكلة: رسالة خطأ "Cannot find module"
**الحل**: 
```bash
cd /home/ubuntu/doc-archive-app
pnpm install
```

### المشكلة: الأيقونات لا تظهر
**الحل**: تأكد من أن الأيقونة موجودة في `icon-symbol.tsx`

---

## 📚 موارد مفيدة

- **Tailwind CSS**: https://tailwindcss.com/docs
- **React Native**: https://reactnative.dev/docs/getting-started
- **Expo**: https://docs.expo.dev/
- **TypeScript**: https://www.typescriptlang.org/docs/

---

## ✅ نصائح مهمة

1. **احفظ دائماً**: اضغط Ctrl+S بعد كل تعديل
2. **استخدم الـ Comments**: أضف تعليقات لشرح الأكواد المعقدة
3. **اختبر التغييرات**: افتح التطبيق في المتصفح وتحقق من التغييرات
4. **لا تحذف أسطر عشوائياً**: تأكد من فهم الكود قبل حذفه
5. **استخدم Git**: احفظ نسخة من الأكواد قبل التعديل

---

**استمتع بالتطوير! 🎉**
