/**
 * أنواع البيانات الأساسية لتطبيق أرشفة الوثائق
 */

export type DocumentType = 'outgoing' | 'incoming';

export interface Document {
  id: string;
  type: DocumentType;
  referenceNumber: string;
  subject: string;
  date: string; // ISO 8601 format (YYYY-MM-DD)
  pdfUri: string; // Local file URI
  pdfBase64?: string; // Base64 encoded PDF for storage
  createdAt: string; // ISO 8601 timestamp
  updatedAt: string; // ISO 8601 timestamp
}

export interface DocumentListItem extends Document {
  // Additional computed properties for list display
  displayDate: string; // Formatted date for display
}

export interface SearchResult {
  document: Document;
  matchType: 'referenceNumber' | 'date' | 'subject';
  matchText: string;
}

export interface DocumentStats {
  totalDocuments: number;
  outgoingCount: number;
  incomingCount: number;
  recentDocuments: Document[];
}
