import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useDocuments } from '@/lib/document-context';
import { useColors } from '@/hooks/use-colors';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useState } from 'react';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { Platform } from 'react-native';

// Type guard for web environment
const isWeb = Platform.OS === 'web';

export default function DocumentDetailScreen() {
  const router = useRouter();
  const colors = useColors();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getDocumentById, deleteDocument } = useDocuments();

  const [loading, setLoading] = useState(false);

  const document = id ? getDocumentById(id) : null;

  if (!document) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <View className="items-center gap-4">
          <IconSymbol name="doc.text" size={48} color={colors.muted} />
          <Text className="text-lg font-semibold text-foreground">لم نجد الوثيقة</Text>
        </View>
      </ScreenContainer>
    );
  }

  const handleDelete = () => {
    Alert.alert(
      'تأكيد الحذف',
      'هل أنت متأكد من حذف هذه الوثيقة؟',
      [
        {
          text: 'إلغاء',
          onPress: () => {},
          style: 'cancel',
        },
        {
          text: 'حذف',
          onPress: async () => {
            try {
              setLoading(true);
              await deleteDocument(document.id);
              Alert.alert('نجاح', 'تم حذف الوثيقة بنجاح', [
                {
                  text: 'حسناً',
                  onPress: () => {
                    router.back();
                  },
                },
              ]);
            } catch (error) {
              Alert.alert('خطأ', 'فشل حذف الوثيقة');
            } finally {
              setLoading(false);
            }
          },
          style: 'destructive',
        },
      ]
    );
  };

  const handleDownload = async () => {
    try {
      setLoading(true);
      const fileName = `${document.referenceNumber}_${document.date}.pdf`;
      
      if (Platform.OS === 'web') {
        // On web, trigger browser download
        const link = (globalThis.document as any).createElement('a');
        link.href = document.pdfUri;
        link.download = fileName;
        (globalThis.document as any).body.appendChild(link);
        link.click();
        (globalThis.document as any).body.removeChild(link);
        Alert.alert('نجاح', 'تم بدء تحميل الملف');
      } else {
        // On mobile, use FileSystem
        const downloadPath = `${FileSystem.documentDirectory}${fileName}`;
        await FileSystem.copyAsync({
          from: document.pdfUri,
          to: downloadPath,
        });
        Alert.alert('نجاح', `تم تحميل الملف: ${fileName}`);
      }
    } catch (error) {
      console.error('Download error:', error);
      Alert.alert('خطأ', 'فشل تحميل الملف');
    } finally {
      setLoading(false);
    }
  };

  const handleView = async () => {
    try {
      setLoading(true);
      
      if (Platform.OS === 'web') {
        // On web, open in new tab
        (globalThis.window as any)?.open(document.pdfUri, '_blank');
      } else {
        // On mobile, use Sharing to open
        if (await Sharing.isAvailableAsync()) {
          await Sharing.shareAsync(document.pdfUri, {
            mimeType: 'application/pdf',
            dialogTitle: `عرض ${document.referenceNumber}`,
          });
        } else {
          Alert.alert('خطأ', 'العرض غير متاح على هذا الجهاز');
        }
      }
    } catch (error) {
      console.error('View error:', error);
      Alert.alert('خطأ', 'فشل عرض الملف');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="gap-6 pb-6">
          {/* Header */}
          <View className="flex-row items-center justify-between">
            <TouchableOpacity
              onPress={() => router.back()}
              className="p-2"
            >
              <IconSymbol name="chevron.right" size={24} color={colors.foreground} />
            </TouchableOpacity>
            <Text className="text-2xl font-bold text-foreground">تفاصيل الوثيقة</Text>
            <View className="w-10" />
          </View>

          {/* Document Type Badge */}
          <View
            className={
              document.type === 'outgoing'
                ? 'bg-blue-100 dark:bg-blue-900 px-4 py-2 rounded-full self-start'
                : 'bg-green-100 dark:bg-green-900 px-4 py-2 rounded-full self-start'
            }
          >
            <Text
              className={
                document.type === 'outgoing'
                  ? 'text-sm font-semibold text-blue-700 dark:text-blue-300'
                  : 'text-sm font-semibold text-green-700 dark:text-green-300'
              }
            >
              {document.type === 'outgoing' ? 'وثيقة صادرة' : 'وثيقة واردة'}
            </Text>
          </View>

          {/* Document Information */}
          <View className="bg-surface rounded-2xl p-6 gap-4 border border-border">
            {/* Subject */}
            <View className="gap-2">
              <Text className="text-xs font-semibold text-muted uppercase">الموضوع</Text>
              <Text className="text-lg font-semibold text-foreground">
                {document.subject}
              </Text>
            </View>

            {/* Reference Number */}
            <View className="gap-2 pt-4 border-t border-border">
              <Text className="text-xs font-semibold text-muted uppercase">الرقم الإشاري</Text>
              <Text className="text-base font-mono text-foreground">
                {document.referenceNumber}
              </Text>
            </View>

            {/* Date */}
            <View className="gap-2 pt-4 border-t border-border">
              <Text className="text-xs font-semibold text-muted uppercase">التاريخ</Text>
              <Text className="text-base text-foreground">
                {new Date(document.date).toLocaleDateString('ar-SA')}
              </Text>
            </View>

            {/* Created At */}
            <View className="gap-2 pt-4 border-t border-border">
              <Text className="text-xs font-semibold text-muted uppercase">تاريخ الإضافة</Text>
              <Text className="text-sm text-muted">
                {new Date(document.createdAt).toLocaleDateString('ar-SA')}
              </Text>
            </View>
          </View>

          {/* Action Buttons */}
          <View className="gap-3">
            <TouchableOpacity
              onPress={handleView}
              disabled={loading}
              className="bg-primary rounded-xl p-4 flex-row items-center justify-center gap-2 active:opacity-80"
            >
              {loading ? (
                <ActivityIndicator color={colors.background} />
              ) : (
                <>
                  <IconSymbol name="eye" size={20} color={colors.background} />
                  <Text className="text-lg font-semibold text-background">عرض الملف</Text>
                </>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleDownload}
              disabled={loading}
              className="bg-surface border border-primary rounded-xl p-4 flex-row items-center justify-center gap-2 active:opacity-80"
            >
              {loading ? (
                <ActivityIndicator color={colors.primary} />
              ) : (
                <>
                  <IconSymbol name="arrow.down.doc" size={20} color={colors.primary} />
                  <Text className="text-lg font-semibold text-primary">تحميل الملف</Text>
                </>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleDelete}
              disabled={loading}
              className="bg-surface border border-error rounded-xl p-4 flex-row items-center justify-center gap-2 active:opacity-80"
            >
              {loading ? (
                <ActivityIndicator color={colors.error} />
              ) : (
                <>
                  <IconSymbol name="trash" size={20} color={colors.error} />
                  <Text className="text-lg font-semibold text-error">حذف الوثيقة</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
