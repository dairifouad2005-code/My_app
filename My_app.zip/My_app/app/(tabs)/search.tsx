import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator, FlatList, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useDocuments } from '@/lib/document-context';
import { useColors } from '@/hooks/use-colors';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useState, useMemo } from 'react';

export default function SearchScreen() {
  const router = useRouter();
  const colors = useColors();
  const { searchDocuments, loading } = useDocuments();
  const [query, setQuery] = useState('');

  const results = useMemo(() => {
    return searchDocuments(query);
  }, [query, searchDocuments]);

  if (loading) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <ActivityIndicator size="large" color={colors.primary} />
      </ScreenContainer>
    );
  }

  const renderDocument = ({ item }: { item: any }) => (
    <TouchableOpacity
      onPress={() => router.push(`/(tabs)/document-detail?id=${item.id}`)}
      className="bg-surface rounded-xl p-4 border border-border mb-3 active:opacity-70"
    >
      <View className="gap-2">
        <View className="flex-row items-start justify-between gap-2">
          <View className="flex-1 gap-1">
            <Text className="text-sm font-semibold text-foreground" numberOfLines={2}>
              {item.subject}
            </Text>
            <Text className="text-xs text-muted">
              الرقم: {item.referenceNumber}
            </Text>
          </View>
          <View
            className={
              item.type === 'outgoing'
                ? 'bg-blue-100 dark:bg-blue-900 px-3 py-1 rounded-full'
                : 'bg-green-100 dark:bg-green-900 px-3 py-1 rounded-full'
            }
          >
            <Text
              className={
                item.type === 'outgoing'
                  ? 'text-xs font-semibold text-blue-700 dark:text-blue-300'
                  : 'text-xs font-semibold text-green-700 dark:text-green-300'
              }
            >
              {item.type === 'outgoing' ? 'صادر' : 'وارد'}
            </Text>
          </View>
        </View>
        <Text className="text-xs text-muted">
          {item.date}
        </Text>
        <View className="flex-row gap-2 pt-2 border-t border-border">
          <TouchableOpacity
            className="flex-1 flex-row items-center justify-center gap-1 py-2 bg-primary rounded-lg active:opacity-80"
            onPress={() => router.push(`/(tabs)/document-detail?id=${item.id}`)}
          >
            <IconSymbol name="eye" size={16} color={colors.background} />
            <Text className="text-xs font-semibold text-background">عرض</Text>
          </TouchableOpacity>
          <TouchableOpacity
            className="flex-1 flex-row items-center justify-center gap-1 py-2 border border-primary rounded-lg"
            onPress={() => {}}
          >
            <IconSymbol name="arrow.down.doc" size={16} color={colors.primary} />
            <Text className="text-xs font-semibold text-primary">تحميل</Text>
          </TouchableOpacity>
          <TouchableOpacity
            className="flex-1 flex-row items-center justify-center gap-1 py-2 border border-error rounded-lg"
            onPress={() => {}}
          >
            <IconSymbol name="trash" size={16} color={colors.error} />
            <Text className="text-xs font-semibold text-error">حذف</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="p-6">
      <View className="flex-1 gap-4">
        <View className="gap-2">
          <Text className="text-3xl font-bold text-foreground">البحث</Text>
          <Text className="text-sm text-muted">
            ابحث عن وثيقة باستخدام الرقم أو التاريخ أو الموضوع
          </Text>
        </View>

        {/* Search Input */}
        <View className="flex-row items-center gap-2 bg-surface border border-border rounded-xl px-4 py-3">
          <IconSymbol name="magnifyingglass" size={20} color={colors.muted} />
          <TextInput
            placeholder="ابحث هنا..."
            placeholderTextColor={colors.muted}
            value={query}
            onChangeText={setQuery}
            className="flex-1 text-foreground text-base"
            style={{ color: colors.foreground }}
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={() => setQuery('')}>
              <IconSymbol name="xmark" size={20} color={colors.muted} />
            </TouchableOpacity>
          )}
        </View>

        {/* Results */}
        {query.length > 0 ? (
          results.length > 0 ? (
            <View className="flex-1">
              <Text className="text-sm text-muted mb-3">
                وجدنا {results.length} نتيجة
              </Text>
              <FlatList
                data={results}
                renderItem={renderDocument}
                keyExtractor={(item) => item.id}
                scrollEnabled={false}
                contentContainerStyle={{ gap: 8 }}
              />
            </View>
          ) : (
            <View className="flex-1 items-center justify-center gap-4">
              <IconSymbol name="magnifyingglass" size={48} color={colors.muted} />
              <View className="items-center gap-2">
                <Text className="text-lg font-semibold text-foreground">لم نجد نتائج</Text>
                <Text className="text-sm text-muted text-center">
                  حاول البحث بكلمات مختلفة
                </Text>
              </View>
            </View>
          )
        ) : (
          <View className="flex-1 items-center justify-center gap-4">
            <IconSymbol name="magnifyingglass" size={48} color={colors.muted} />
            <View className="items-center gap-2">
              <Text className="text-lg font-semibold text-foreground">ابدأ البحث</Text>
              <Text className="text-sm text-muted text-center">
                أدخل كلمة البحث في الحقل أعلاه
              </Text>
            </View>
          </View>
        )}
      </View>
    </ScreenContainer>
  );
}
