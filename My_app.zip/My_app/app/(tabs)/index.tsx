import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useDocuments } from '@/lib/document-context';
import { useColors } from '@/hooks/use-colors';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { cn } from '@/lib/utils';

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const { getStats, loading } = useDocuments();
  const stats = getStats();

  if (loading) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <ActivityIndicator size="large" color={colors.primary} />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1 gap-6">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-4xl font-bold text-foreground">نظام الأرشفة</Text>
            <Text className="text-base text-muted">إدارة الوثائق الصادرة والواردة</Text>
          </View>

          {/* Statistics Cards */}
          <View className="gap-3">
            {/* Total Documents */}
            <View className="flex-row gap-3">
              <View className="flex-1 bg-primary rounded-2xl p-6 gap-2">
                <View className="flex-row items-center gap-2">
                  <IconSymbol name="doc.text" size={24} color={colors.background} />
                  <Text className="text-sm text-background opacity-80">إجمالي الوثائق</Text>
                </View>
                <Text className="text-3xl font-bold text-background">
                  {stats.totalDocuments}
                </Text>
              </View>

              {/* Outgoing */}
              <View className="flex-1 bg-surface rounded-2xl p-6 gap-2 border border-border">
                <View className="flex-row items-center gap-2">
                  <IconSymbol name="arrow.up.doc" size={24} color={colors.primary} />
                  <Text className="text-sm text-muted">الصادر</Text>
                </View>
                <Text className="text-3xl font-bold text-foreground">
                  {stats.outgoingCount}
                </Text>
              </View>
            </View>

            {/* Incoming */}
            <View className="flex-1 bg-surface rounded-2xl p-6 gap-2 border border-border">
              <View className="flex-row items-center gap-2">
                <IconSymbol name="arrow.down.doc" size={24} color={colors.primary} />
                <Text className="text-sm text-muted">الوارد</Text>
              </View>
              <Text className="text-3xl font-bold text-foreground">
                {stats.incomingCount}
              </Text>
            </View>
          </View>

          {/* Action Buttons */}
          <View className="gap-3">
            <TouchableOpacity
              onPress={() => router.push('/add-document')}
              className="bg-primary rounded-2xl p-4 flex-row items-center justify-center gap-3 active:opacity-80"
            >
              <IconSymbol name="plus.circle.fill" size={24} color={colors.background} />
              <Text className="text-lg font-semibold text-background">إضافة وثيقة جديدة</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => router.push('/(tabs)/search')}
              className="bg-surface rounded-2xl p-4 flex-row items-center justify-center gap-3 border border-border active:opacity-80"
            >
              <IconSymbol name="magnifyingglass" size={24} color={colors.primary} />
              <Text className="text-lg font-semibold text-foreground">البحث عن وثيقة</Text>
            </TouchableOpacity>
          </View>

          {/* Recent Documents */}
          {stats.recentDocuments.length > 0 && (
            <View className="gap-3">
              <Text className="text-lg font-semibold text-foreground">آخر الوثائق المضافة</Text>
              <View className="gap-2">
                {stats.recentDocuments.map((doc) => (
                  <TouchableOpacity
                    key={doc.id}
                    onPress={() => router.push(`/(tabs)/document-detail?id=${doc.id}`)}
                    className="bg-surface rounded-xl p-4 border border-border active:opacity-70"
                  >
                    <View className="flex-row items-center justify-between gap-2">
                      <View className="flex-1 gap-1">
                        <Text className="text-sm font-semibold text-foreground" numberOfLines={1}>
                          {doc.subject}
                        </Text>
                        <Text className="text-xs text-muted">
                          {doc.referenceNumber} • {doc.date}
                        </Text>
                      </View>
                      <View
                        className={cn(
                          'px-3 py-1 rounded-full',
                          doc.type === 'outgoing'
                            ? 'bg-blue-100 dark:bg-blue-900'
                            : 'bg-green-100 dark:bg-green-900'
                        )}
                      >
                        <Text
                          className={cn(
                            'text-xs font-semibold',
                            doc.type === 'outgoing'
                              ? 'text-blue-700 dark:text-blue-300'
                              : 'text-green-700 dark:text-green-300'
                          )}
                        >
                          {doc.type === 'outgoing' ? 'صادر' : 'وارد'}
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}

          {/* Empty State */}
          {stats.totalDocuments === 0 && (
            <View className="flex-1 items-center justify-center gap-4 py-8">
              <IconSymbol name="doc.text" size={48} color={colors.muted} />
              <View className="items-center gap-2">
                <Text className="text-lg font-semibold text-foreground">لا توجد وثائق</Text>
                <Text className="text-sm text-muted text-center">
                  ابدأ بإضافة وثيقة جديدة لبدء الأرشفة
                </Text>
              </View>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
