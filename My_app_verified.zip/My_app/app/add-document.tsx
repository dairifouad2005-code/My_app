import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useDocuments } from '@/lib/document-context';
import { useColors } from '@/hooks/use-colors';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useState } from 'react';
import * as DocumentPicker from 'expo-document-picker';
import DateTimePicker from '@react-native-community/datetimepicker';

export default function AddDocumentScreen() {
  const router = useRouter();
  const colors = useColors();
  const { addDocument } = useDocuments();

  const [type, setType] = useState<'outgoing' | 'incoming'>('outgoing');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [subject, setSubject] = useState('');
  const [date, setDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [selectedFile, setSelectedFile] = useState<{ name: string; uri: string } | null>(null);
  const [loading, setLoading] = useState(false);

  const handleDateChange = (event: any, selectedDate?: Date) => {
    if (Platform.OS === 'android') {
      setShowDatePicker(false);
    }
    if (selectedDate) {
      setDate(selectedDate);
    }
  };

  const handlePickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/pdf',
      });

      if (result.assets && result.assets.length > 0) {
        const file = result.assets[0];
        setSelectedFile({
          name: file.name,
          uri: file.uri,
        });
      }
    } catch (error) {
      Alert.alert('خطأ', 'فشل اختيار الملف');
    }
  };

  const handleAddDocument = async () => {
    if (!referenceNumber.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال الرقم الإشاري');
      return;
    }

    if (!subject.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال موضوع الوثيقة');
      return;
    }

    if (!selectedFile) {
      Alert.alert('خطأ', 'يرجى اختيار ملف PDF');
      return;
    }

    try {
      setLoading(true);

      const dateString = date.toISOString().split('T')[0];

      await addDocument({
        type,
        referenceNumber: referenceNumber.trim(),
        subject: subject.trim(),
        date: dateString,
        pdfUri: selectedFile.uri,
      });

      Alert.alert('نجاح', 'تم إضافة الوثيقة بنجاح', [
        {
          text: 'حسناً',
          onPress: () => {
            router.back();
          },
        },
      ]);
    } catch (error) {
      Alert.alert('خطأ', 'فشل إضافة الوثيقة');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="gap-6 pb-6">
          {/* Header */}
          <View className="flex-row items-center justify-between">
            <View className="gap-2">
              <Text className="text-3xl font-bold text-foreground">إضافة وثيقة</Text>
              <Text className="text-sm text-muted">أضف وثيقة جديدة إلى النظام</Text>
            </View>
            <TouchableOpacity
              onPress={() => router.back()}
              className="p-2"
            >
              <IconSymbol name="xmark" size={24} color={colors.foreground} />
            </TouchableOpacity>
          </View>

          {/* Document Type Selection */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground">نوع الوثيقة</Text>
            <View className="flex-row gap-3">
              <TouchableOpacity
                onPress={() => setType('outgoing')}
                className={`flex-1 p-4 rounded-xl border-2 items-center gap-2 ${
                  type === 'outgoing'
                    ? 'bg-primary border-primary'
                    : 'bg-surface border-border'
                }`}
              >
                <IconSymbol
                  name="arrow.up.doc"
                  size={24}
                  color={type === 'outgoing' ? colors.background : colors.primary}
                />
                <Text
                  className={`text-sm font-semibold ${
                    type === 'outgoing' ? 'text-background' : 'text-foreground'
                  }`}
                >
                  صادر
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => setType('incoming')}
                className={`flex-1 p-4 rounded-xl border-2 items-center gap-2 ${
                  type === 'incoming'
                    ? 'bg-primary border-primary'
                    : 'bg-surface border-border'
                }`}
              >
                <IconSymbol
                  name="arrow.down.doc"
                  size={24}
                  color={type === 'incoming' ? colors.background : colors.primary}
                />
                <Text
                  className={`text-sm font-semibold ${
                    type === 'incoming' ? 'text-background' : 'text-foreground'
                  }`}
                >
                  وارد
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Reference Number */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">الرقم الإشاري</Text>
            <TextInput
              placeholder="أدخل الرقم الإشاري"
              placeholderTextColor={colors.muted}
              value={referenceNumber}
              onChangeText={setReferenceNumber}
              className="bg-surface border border-border rounded-xl px-4 py-3 text-foreground"
              style={{ color: colors.foreground }}
            />
          </View>

          {/* Subject */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">موضوع الوثيقة</Text>
            <TextInput
              placeholder="أدخل موضوع الوثيقة"
              placeholderTextColor={colors.muted}
              value={subject}
              onChangeText={setSubject}
              multiline
              numberOfLines={4}
              className="bg-surface border border-border rounded-xl px-4 py-3 text-foreground"
              style={{ color: colors.foreground, textAlignVertical: 'top' }}
            />
          </View>

          {/* Date */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">التاريخ</Text>
            <TouchableOpacity
              onPress={() => setShowDatePicker(true)}
              className="bg-surface border border-border rounded-xl px-4 py-3 flex-row items-center justify-between"
            >
              <Text className="text-foreground">
                {date.toLocaleDateString('ar-SA')}
              </Text>
              <IconSymbol name="chevron.right" size={20} color={colors.muted} />
            </TouchableOpacity>

            {showDatePicker && (
              <DateTimePicker
                value={date}
                mode="date"
                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                onChange={handleDateChange}
                textColor={colors.foreground}
              />
            )}
          </View>

          {/* File Selection */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">ملف PDF</Text>
            <TouchableOpacity
              onPress={handlePickDocument}
              className="bg-surface border-2 border-dashed border-border rounded-xl px-4 py-6 items-center gap-2"
            >
              <IconSymbol name="arrow.up.doc" size={32} color={colors.primary} />
              {selectedFile ? (
                <View className="items-center gap-1">
                  <Text className="text-sm font-semibold text-foreground">
                    {selectedFile.name}
                  </Text>
                  <Text className="text-xs text-muted">اضغط لتغيير الملف</Text>
                </View>
              ) : (
                <View className="items-center gap-1">
                  <Text className="text-sm font-semibold text-foreground">
                    اختر ملف PDF
                  </Text>
                  <Text className="text-xs text-muted">اضغط لاختيار الملف</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          {/* Action Buttons */}
          <View className="gap-3 pt-4">
          <TouchableOpacity
            onPress={handleAddDocument}
            disabled={loading}
            className="bg-primary rounded-xl p-4 flex-row items-center justify-center gap-2 active:opacity-80"
          >
              {loading ? (
                <ActivityIndicator color={colors.background} />
              ) : (
                <>
                  <IconSymbol name="checkmark" size={20} color={colors.background} />
                  <Text className="text-lg font-semibold text-background">حفظ الوثيقة</Text>
                </>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => router.back()}
              disabled={loading}
              className="bg-surface border border-border rounded-xl p-4 flex-row items-center justify-center gap-2 active:opacity-80"
            >
              <IconSymbol name="xmark" size={20} color={colors.foreground} />
              <Text className="text-lg font-semibold text-foreground">إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
