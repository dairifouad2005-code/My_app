import { View, Text, TouchableOpacity, Image, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useGoogleAuth } from '@/lib/google-auth-context';
import { useDocuments } from '@/lib/document-context';
import { useColors } from '@/hooks/use-colors';
import { IconSymbol } from '@/components/ui/icon-symbol';

export default function ProfileScreen() {
  const { user, login, logout, loading } = useGoogleAuth();
  const { syncWithCloud, loading: syncLoading } = useDocuments();
  const colors = useColors();

  const handleLogin = async () => {
    try {
      await login();
      Alert.alert('نجاح', 'تم تسجيل الدخول بنجاح');
    } catch (error) {
      Alert.alert('خطأ', 'فشل تسجيل الدخول');
    }
  };

  const handleLogout = async () => {
    Alert.alert(
      'تسجيل الخروج',
      'هل أنت متأكد من رغبتك في تسجيل الخروج؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'خروج', style: 'destructive', onPress: logout }
      ]
    );
  };

  const handleSync = async () => {
    try {
      await syncWithCloud();
      Alert.alert('نجاح', 'تمت المزامنة مع Google Drive بنجاح');
    } catch (error) {
      Alert.alert('خطأ', 'فشلت المزامنة');
    }
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="gap-8">
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">الملف الشخصي</Text>
            <Text className="text-sm text-muted">إدارة حسابك وإعدادات التخزين السحابي</Text>
          </View>

          {user ? (
            <View className="gap-6">
              {/* User Info Card */}
              <View className="bg-surface border border-border p-6 rounded-2xl items-center gap-4">
                {user.photo ? (
                  <Image 
                    source={{ uri: user.photo }} 
                    className="w-20 h-20 rounded-full"
                  />
                ) : (
                  <View className="w-20 h-20 rounded-full bg-primary items-center justify-center">
                    <Text className="text-background text-2xl font-bold">
                      {user.name?.[0] || user.email[0].toUpperCase()}
                    </Text>
                  </View>
                )}
                <View className="items-center">
                  <Text className="text-xl font-bold text-foreground">{user.name}</Text>
                  <Text className="text-sm text-muted">{user.email}</Text>
                </View>
              </View>

              {/* Cloud Actions */}
              <View className="gap-3">
                <Text className="text-sm font-semibold text-foreground px-1">التخزين السحابي</Text>
                
                <TouchableOpacity
                  onPress={handleSync}
                  disabled={syncLoading}
                  className="bg-surface border border-border p-4 rounded-xl flex-row items-center justify-between"
                >
                  <View className="flex-row items-center gap-3">
                    <IconSymbol name="cloud.fill" size={24} color={colors.primary} />
                    <Text className="text-base font-medium text-foreground">مزامنة الآن</Text>
                  </View>
                  {syncLoading ? (
                    <ActivityIndicator size="small" color={colors.primary} />
                  ) : (
                    <IconSymbol name="chevron.right" size={20} color={colors.muted} />
                  )}
                </TouchableOpacity>

                <View className="bg-primary/10 p-4 rounded-xl flex-row gap-3 items-center">
                  <IconSymbol name="info.circle.fill" size={20} color={colors.primary} />
                  <Text className="text-xs text-primary flex-1">
                    سيتم رفع جميع الوثائق الجديدة تلقائياً إلى حسابك في Google Drive عند توفر اتصال بالإنترنت.
                  </Text>
                </View>
              </View>

              {/* Account Actions */}
              <TouchableOpacity
                onPress={handleLogout}
                className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl flex-row items-center justify-center gap-2"
              >
                <IconSymbol name="rectangle.portrait.and.arrow.right" size={20} color="#ef4444" />
                <Text className="text-base font-semibold text-red-500">تسجيل الخروج</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View className="flex-1 justify-center items-center gap-6 py-12">
              <View className="w-20 h-20 bg-surface border border-border rounded-3xl items-center justify-center">
                <IconSymbol name="person.fill" size={40} color={colors.muted} />
              </View>
              <View className="items-center gap-2">
                <Text className="text-xl font-bold text-foreground text-center">سجل دخولك لتفعيل التخزين السحابي</Text>
                <Text className="text-sm text-muted text-center px-6">
                  عند تسجيل الدخول، سيتم حفظ نسخة احتياطية من جميع وثائقك في حسابك الخاص على Google Drive لتتمكن من الوصول إليها من أي جهاز.
                </Text>
              </View>
              
              <TouchableOpacity
                onPress={handleLogin}
                disabled={loading}
                className="bg-primary w-full py-4 rounded-xl flex-row items-center justify-center gap-3"
              >
                {loading ? (
                  <ActivityIndicator color={colors.background} />
                ) : (
                  <>
                    <IconSymbol name="person.badge.key.fill" size={20} color={colors.background} />
                    <Text className="text-lg font-semibold text-background">تسجيل الدخول عبر Google</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
