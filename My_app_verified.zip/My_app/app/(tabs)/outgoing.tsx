import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator, FlatList } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useDocuments } from '@/lib/document-context';
import { useColors } from '@/hooks/use-colors';
import { IconSymbol } from '@/components/ui/icon-symbol';

export default function OutgoingScreen() {
  const router = useRouter();
  const colors = useColors();
  const { getDocumentsByType, loading } = useDocuments();
  const documents = getDocumentsByType('outgoing');

  if (loading) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <ActivityIndicator size="large" color={colors.primary} />
      </ScreenContainer>
    );
  }

  const renderDocument = ({ item }: { item: any }) => (
    <TouchableOpacity
      onPress={() => router.push(`/(tabs)/document-detail?id=${item.id}`)}
      className="bg-surface rounded-xl p-4 border border-border mb-3 active:opacity-70"
    >
      <View className="gap-2">
        <View className="flex-row items-start justify-between gap-2">
          <View className="flex-1 gap-1">
            <Text className="text-sm font-semibold text-foreground" numberOfLines={2}>
              {item.subject}
            </Text>
            <Text className="text-xs text-muted">
              الرقم: {item.referenceNumber}
            </Text>
          </View>
          <View className="bg-blue-100 dark:bg-blue-900 px-3 py-1 rounded-full">
            <Text className="text-xs font-semibold text-blue-700 dark:text-blue-300">
              صادر
            </Text>
          </View>
        </View>
        <Text className="text-xs text-muted">
          {item.date}
        </Text>
        <View className="flex-row gap-2 pt-2 border-t border-border">
          <TouchableOpacity
            className="flex-1 flex-row items-center justify-center gap-1 py-2 bg-primary rounded-lg active:opacity-80"
            onPress={() => router.push(`/(tabs)/document-detail?id=${item.id}`)}
          >
            <IconSymbol name="eye" size={16} color={colors.background} />
            <Text className="text-xs font-semibold text-background">عرض</Text>
          </TouchableOpacity>
          <TouchableOpacity
            className="flex-1 flex-row items-center justify-center gap-1 py-2 border border-primary rounded-lg"
            onPress={() => {}}
          >
            <IconSymbol name="arrow.down.doc" size={16} color={colors.primary} />
            <Text className="text-xs font-semibold text-primary">تحميل</Text>
          </TouchableOpacity>
          <TouchableOpacity
            className="flex-1 flex-row items-center justify-center gap-1 py-2 border border-error rounded-lg"
            onPress={() => {}}
          >
            <IconSymbol name="trash" size={16} color={colors.error} />
            <Text className="text-xs font-semibold text-error">حذف</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="p-6">
      <View className="flex-1 gap-4">
        <View className="gap-2">
          <Text className="text-3xl font-bold text-foreground">الوثائق الصادرة</Text>
          <Text className="text-sm text-muted">
            {documents.length} وثيقة صادرة
          </Text>
        </View>

        {documents.length > 0 ? (
          <FlatList
            data={documents}
            renderItem={renderDocument}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            contentContainerStyle={{ gap: 8 }}
          />
        ) : (
          <View className="flex-1 items-center justify-center gap-4">
            <IconSymbol name="doc.text" size={48} color={colors.muted} />
            <View className="items-center gap-2">
              <Text className="text-lg font-semibold text-foreground">لا توجد وثائق صادرة</Text>
              <Text className="text-sm text-muted text-center">
                ابدأ بإضافة وثيقة صادرة جديدة
              </Text>
            </View>
          </View>
        )}
      </View>
    </ScreenContainer>
  );
}
