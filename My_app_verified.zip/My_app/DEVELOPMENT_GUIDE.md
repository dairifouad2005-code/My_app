# 📚 دليل تطوير تطبيق أرشفة الوثائق

## 🎯 البداية السريعة

### الخطوة 1: فتح المشروع
```bash
مسار المشروع: /home/ubuntu/doc-archive-app
```

### الخطوة 2: استخدام VS Code (الأفضل)
1. افتح VS Code
2. اذهب إلى File → Open Folder
3. اختر المجلد `/home/ubuntu/doc-archive-app`

### الخطوة 3: ثبت الإضافات المفيدة
في VS Code، اضغط Ctrl+Shift+X وثبت:
- **ES7+ React/Redux/React-Native snippets**
- **Tailwind CSS IntelliSense**
- **TypeScript Vue Plugin**

---

## 📁 هيكل المشروع الرئيسي

```
doc-archive-app/
├── app/                    # جميع شاشات التطبيق
│   ├── (tabs)/            # الشاشات الرئيسية (التنقل السفلي)
│   │   ├── index.tsx      # الشاشة الرئيسية
│   │   ├── outgoing.tsx   # الوثائق الصادرة
│   │   ├── incoming.tsx   # الوثائق الواردة
│   │   ├── search.tsx     # البحث
│   │   └── document-detail.tsx  # تفاصيل الوثيقة
│   ├── add-document.tsx   # إضافة وثيقة جديدة
│   └── _layout.tsx        # الملف الرئيسي
├── lib/                   # المنطق والحالة
│   ├── document-context.tsx  # إدارة الوثائق
│   └── theme-provider.tsx    # إدارة الألوان
├── types/                 # أنواع البيانات
│   └── document.ts
├── components/            # المكونات المشتركة
├── hooks/                 # React Hooks
├── assets/               # الصور والأيقونات
└── package.json          # المكتبات
```

---

## 🔑 الملفات الأساسية وشرح وظائفها

### 1. `lib/document-context.tsx` - إدارة الوثائق
يحتوي على جميع العمليات على الوثائق:
```typescript
- addDocument()      // إضافة وثيقة
- deleteDocument()   // حذف وثيقة
- searchDocuments()  // البحث
- getOutgoing()      // الوثائق الصادرة
- getIncoming()      // الوثائق الواردة
```

### 2. `types/document.ts` - بنية الوثيقة
```typescript
interface Document {
  id: string;                    // معرف فريد
  type: 'outgoing' | 'incoming'; // نوع الوثيقة
  referenceNumber: string;       // الرقم الإشاري
  subject: string;               // الموضوع
  date: string;                  // التاريخ
  pdfUri: string;                // رابط الملف
  createdAt: string;             // تاريخ الإنشاء
}
```

### 3. `app/(tabs)/index.tsx` - الشاشة الرئيسية
تعرض الإحصائيات والوثائق الأخيرة

### 4. `app/(tabs)/search.tsx` - البحث
نظام بحث ذكي بالرقم والتاريخ والموضوع

### 5. `app/(tabs)/document-detail.tsx` - تفاصيل الوثيقة
أزرار: عرض، تحميل، حذف

---

## 🛠️ كيفية التعديل على الأكواد

### مثال 1: تغيير نص الزر
**الملف**: `app/(tabs)/index.tsx`

ابحث عن:
```typescript
<Text className="text-2xl font-bold">أضف وثيقة جديدة</Text>
```

غيره إلى:
```typescript
<Text className="text-2xl font-bold">إضافة وثيقة</Text>
```

احفظ الملف (Ctrl+S) - التطبيق سيحدّث نفسه تلقائياً!

### مثال 2: تغيير الألوان
**الملف**: `theme.config.js`

```javascript
const themeColors = {
  primary: { light: '#0a7ea4', dark: '#0a7ea4' },      // اللون الأساسي
  background: { light: '#ffffff', dark: '#151718' },   // الخلفية
  foreground: { light: '#11181C', dark: '#ECEDEE' },   // النص
};
```

استخدم الألوان في الأكواد:
```typescript
<View className="bg-primary">         {/* خلفية زرقاء */}
<Text className="text-foreground">    {/* نص أسود/أبيض */}
<View className="border border-border"> {/* حد رمادي */}
```

### مثال 3: إضافة حقل جديد للوثيقة

**الخطوة 1**: عدّل `types/document.ts`
```typescript
interface Document {
  // ... الحقول الموجودة
  notes?: string;  // أضف هذا الحقل
}
```

**الخطوة 2**: عدّل `app/add-document.tsx`
```typescript
// أضف state جديد:
const [notes, setNotes] = useState('');

// أضف input جديد:
<TextInput
  placeholder="ملاحظات (اختياري)"
  value={notes}
  onChangeText={setNotes}
  className="border border-border rounded-lg p-3"
/>
```

---

## 🔍 نصائح للبحث والاستبدال السريع

في VS Code:
- **Ctrl+F**: البحث عن نص
- **Ctrl+H**: البحث والاستبدال
- **Ctrl+Shift+F**: البحث في جميع الملفات

مثال: تغيير كل "وثيقة" إلى "ملف":
1. اضغط Ctrl+H
2. اكتب "وثيقة" في البحث
3. اكتب "ملف" في الاستبدال
4. اضغط "Replace All"

---

## 🚀 تشغيل التطبيق

### على الويب:
```bash
cd /home/ubuntu/doc-archive-app
pnpm dev
```
ثم افتح: https://8081-i3a9lixdpz7vwdpuzjtss-f988e398.us2.manus.computer

### على الهاتف:
```bash
pnpm ios    # للـ iPhone
pnpm android # للـ Android
```

---

## 📝 أمثلة عملية

### إضافة زر جديد
```typescript
<TouchableOpacity
  onPress={() => {
    console.log('تم الضغط');
  }}
  className="bg-primary rounded-lg p-4 active:opacity-80"
>
  <Text className="text-white font-bold">اسم الزر</Text>
</TouchableOpacity>
```

### إضافة شاشة جديدة
1. أنشئ ملف جديد في `app/(tabs)/new-screen.tsx`
2. أضف الشاشة في `app/(tabs)/_layout.tsx`:
```typescript
<Tabs.Screen
  name="new-screen"
  options={{
    title: "اسم الشاشة",
    tabBarIcon: ({ color }) => <IconSymbol size={28} name="icon-name" color={color} />,
  }}
/>
```

---

## 🐛 حل المشاكل الشائعة

| المشكلة | الحل |
|--------|------|
| الأكواد لا تتحدث | احفظ الملف (Ctrl+S) |
| خطأ "Cannot find module" | `cd /home/ubuntu/doc-archive-app && pnpm install` |
| الأيقونات لا تظهر | تأكد من وجودها في `icon-symbol.tsx` |
| الألوان غير صحيحة | تحقق من `theme.config.js` |

---

## 📚 موارد مفيدة

- **Tailwind CSS**: https://tailwindcss.com/docs
- **React Native**: https://reactnative.dev/docs
- **Expo**: https://docs.expo.dev/
- **TypeScript**: https://www.typescriptlang.org/docs/

---

## ✅ نصائح مهمة

1. **احفظ دائماً**: Ctrl+S بعد كل تعديل
2. **استخدم التعليقات**: اشرح الأكواد المعقدة
3. **اختبر التغييرات**: افتح التطبيق وتحقق
4. **لا تحذف عشوائياً**: افهم الكود أولاً
5. **استخدم Git**: احفظ نسخة قبل التعديل

---

## 🎉 استمتع بالتطوير!

إذا واجهت أي مشكلة، تذكر:
- اقرأ رسالة الخطأ بعناية
- ابحث عن الملف الذي يحتوي على الخطأ
- تراجع عن التغييرات إذا لزم الأمر
