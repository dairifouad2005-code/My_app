import React, { createContext, useContext, useState, useEffect } from 'react';
import * as Google from '@react-native-google-signin/google-signin';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { GoogleUser } from '@/types/document';
import { Platform } from 'react-native';

interface GoogleAuthContextType {
  user: GoogleUser | null;
  loading: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
}

const GoogleAuthContext = createContext<GoogleAuthContextType | undefined>(undefined);

const GOOGLE_USER_KEY = '@google_user_data';

export function GoogleAuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<GoogleUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Configure Google Sign-In
    // Note: In a real app, these IDs would come from environment variables
    Google.GoogleSignin.configure({
      scopes: ['https://www.googleapis.com/auth/drive.file'], // Scope for Google Drive access
      webClientId: 'YOUR_WEB_CLIENT_ID.apps.googleusercontent.com', // Needed for getting accessToken
      offlineAccess: true,
    });

    checkExistingUser();
  }, []);

  const checkExistingUser = async () => {
    try {
      const savedUser = await AsyncStorage.getItem(GOOGLE_USER_KEY);
      if (savedUser) {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser);
        
        // Try to refresh token if needed
        const currentUser = await Google.GoogleSignin.getCurrentUser();
        if (currentUser) {
          const tokens = await Google.GoogleSignin.getTokens();
          if (currentUser && tokens) {
            const updatedUser: GoogleUser = {
              id: currentUser.user.id,
              name: currentUser.user.name,
              email: currentUser.user.email,
              photo: currentUser.user.photo,
              accessToken: tokens.accessToken,
            };
            setUser(updatedUser);
            await AsyncStorage.setItem(GOOGLE_USER_KEY, JSON.stringify(updatedUser));
          }
        }
      }
    } catch (error) {
      console.error('Error checking existing user:', error);
    } finally {
      setLoading(false);
    }
  };

  const login = async () => {
    try {
      setLoading(true);
      await Google.GoogleSignin.hasPlayServices();
      const userInfo = await Google.GoogleSignin.signIn();
      const tokens = await Google.GoogleSignin.getTokens();

      const googleUser: GoogleUser = {
        id: userInfo.data?.user.id || '',
        name: userInfo.data?.user.name || null,
        email: userInfo.data?.user.email || '',
        photo: userInfo.data?.user.photo || null,
        accessToken: tokens.accessToken,
      };

      setUser(googleUser);
      await AsyncStorage.setItem(GOOGLE_USER_KEY, JSON.stringify(googleUser));
    } catch (error) {
      console.error('Google Sign-In Error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      setLoading(true);
      await Google.GoogleSignin.signOut();
      setUser(null);
      await AsyncStorage.removeItem(GOOGLE_USER_KEY);
    } catch (error) {
      console.error('Google Sign-Out Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <GoogleAuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </GoogleAuthContext.Provider>
  );
}

export function useGoogleAuth() {
  const context = useContext(GoogleAuthContext);
  if (context === undefined) {
    throw new Error('useGoogleAuth must be used within a GoogleAuthProvider');
  }
  return context;
}
