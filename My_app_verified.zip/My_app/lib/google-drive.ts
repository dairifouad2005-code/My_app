import * as FileSystem from 'expo-file-system';

const GOOGLE_DRIVE_API_URL = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
const GOOGLE_DRIVE_METADATA_URL = 'https://www.googleapis.com/drive/v3/files';

export async function uploadToGoogleDrive(
  accessToken: string,
  fileUri: string,
  fileName: string,
  mimeType: string = 'application/pdf'
) {
  try {
    const fileInfo = await FileSystem.getInfoAsync(fileUri);
    if (!fileInfo.exists) {
      throw new Error('File does not exist');
    }

    const boundary = 'foo_bar_baz';
    const metadata = {
      name: fileName,
      mimeType: mimeType,
      parents: ['root'], // You can specify a folder ID here if needed
    };

    const metadataPart = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(
      metadata
    )}\r\n`;
    const fileHeaderPart = `--${boundary}\r\nContent-Type: ${mimeType}\r\n\r\n`;
    const fileFooterPart = `\r\n--${boundary}--`;

    // Read file as base64
    const fileBase64 = await FileSystem.readAsStringAsync(fileUri, {
      encoding: 'base64',
    });

    // Google Drive Multipart Upload requires the body to be in a specific format
    // Since we are in React Native, we can use a Blob or a specific library, 
    // but for simplicity and reliability with Expo, we can use a multipart request.
    
    const body = `${metadataPart}${fileHeaderPart}${fileBase64}${fileFooterPart}`;
    
    // Note: Standard multipart/related with base64 might not work directly with fetch this way.
    // Google Drive also supports simple upload if we don't need metadata in the same request,
    // or we can use two steps: 1. Create metadata, 2. Upload content.
    
    // Let's use the two-step approach for better reliability in RN
    
    // Step 1: Create Metadata
    const createResponse = await fetch(GOOGLE_DRIVE_METADATA_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(metadata),
    });

    const createData = await createResponse.json();
    if (!createResponse.ok) {
      throw new Error(`Failed to create metadata: ${JSON.stringify(createData)}`);
    }

    const fileId = createData.id;

    // Step 2: Upload Content
    const uploadResponse = await fetch(
      `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`,
      {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': mimeType,
        },
        body: await FileSystem.readAsStringAsync(fileUri, { encoding: 'base64' }),
      }
    );

    if (!uploadResponse.ok) {
      const errorData = await uploadResponse.json();
      throw new Error(`Failed to upload content: ${JSON.stringify(errorData)}`);
    }

    return fileId;
  } catch (error) {
    console.error('Error uploading to Google Drive:', error);
    throw error;
  }
}

export async function downloadFromGoogleDrive(accessToken: string, fileId: string, localUri: string) {
  try {
    const response = await fetch(
      `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    if (!response.ok) {
      throw new Error('Failed to download file');
    }

    const blob = await response.blob();
    const reader = new FileReader();
    
    return new Promise((resolve, reject) => {
      reader.onloadend = async () => {
        try {
          const base64data = (reader.result as string).split(',')[1];
          await FileSystem.writeAsStringAsync(localUri, base64data, {
            encoding: 'base64',
          });
          resolve(localUri);
        } catch (e) {
          reject(e);
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error('Error downloading from Google Drive:', error);
    throw error;
  }
}

export async function deleteFromGoogleDrive(accessToken: string, fileId: string) {
  try {
    const response = await fetch(`${GOOGLE_DRIVE_METADATA_URL}/${fileId}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!response.ok && response.status !== 404) {
      throw new Error('Failed to delete file from Google Drive');
    }
  } catch (error) {
    console.error('Error deleting from Google Drive:', error);
    throw error;
  }
}
